import { useEffect } from 'react';
import './App.css';

// Components
import Navigation from './components/Navigation';

// Sections
import Hero from './sections/Hero';
import About from './sections/About';
import Projects from './sections/Projects';
import Skills from './sections/Skills';
import Education from './sections/Education';
import WorkExperience from './sections/WorkExperience';
import CommunityWork from './sections/CommunityWork';
import Awards from './sections/Awards';
import FileManager from './sections/FileManager';
import Contact from './sections/Contact';

function App() {
  useEffect(() => {
    // Smooth scroll for anchor links
    document.querySelectorAll('a[href^="#"]').forEach((anchor) => {
      anchor.addEventListener('click', function (e) {
        e.preventDefault();
        const href = (e.currentTarget as HTMLAnchorElement).getAttribute('href');
        if (href) {
          const target = document.querySelector(href);
          if (target) {
            target.scrollIntoView({ behavior: 'smooth' });
          }
        }
      });
    });
  }, []);

  return (
    <div className="min-h-screen bg-white">
      {/* Navigation */}
      <Navigation />

      {/* Main Content */}
      <main className="relative">
        {/* Hero Section */}
        <Hero />

        {/* Content Sections */}
        <div className="w-full px-4 md:px-8 lg:px-12 py-8 space-y-6">
          <div className="max-w-5xl mx-auto space-y-6">
            {/* About Section */}
            <About />

            {/* Projects Section */}
            <Projects />

            {/* Skills Section */}
            <Skills />

            {/* Education Section */}
            <Education />

            {/* Work Experience Section */}
            <WorkExperience />

            {/* Community Work Section */}
            <CommunityWork />

            {/* Awards Section */}
            <Awards />

            {/* File Manager Section */}
            <FileManager />
          </div>
        </div>

        {/* Contact Section */}
        <Contact />
      </main>
    </div>
  );
}

export default App;
