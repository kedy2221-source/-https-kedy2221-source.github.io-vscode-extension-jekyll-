import { useState, useRef, useCallback } from 'react';
import { 
  Upload, 
  Download, 
  File, 
  FileText, 
  Image, 
  FileSpreadsheet,
  Trash2,
  X,
  CheckCircle,
  AlertCircle
} from 'lucide-react';

interface FileItem {
  id: string;
  name: string;
  type: string;
  size: string;
  uploadedAt: string;
  category: 'document' | 'image' | 'spreadsheet' | 'other';
}

const mockFiles: FileItem[] = [
  {
    id: '1',
    name: 'Keiday_Ali_CV_2024.pdf',
    type: 'application/pdf',
    size: '245 KB',
    uploadedAt: '2024-01-15',
    category: 'document',
  },
  {
    id: '2',
    name: 'Research_Portfolio.pdf',
    type: 'application/pdf',
    size: '3.2 MB',
    uploadedAt: '2024-01-10',
    category: 'document',
  },
  {
    id: '3',
    name: 'CERC_Migration_Report.pdf',
    type: 'application/pdf',
    size: '1.8 MB',
    uploadedAt: '2023-12-20',
    category: 'document',
  },
  {
    id: '4',
    name: 'Policy_Analysis_Data.xlsx',
    type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
    size: '456 KB',
    uploadedAt: '2023-11-15',
    category: 'spreadsheet',
  },
];

const FileManager = () => {
  const [files, setFiles] = useState<FileItem[]>(mockFiles);
  const [isDragging, setIsDragging] = useState(false);
  const [uploadProgress, setUploadProgress] = useState<{ [key: string]: number }>({});
  const [notification, setNotification] = useState<{ type: 'success' | 'error'; message: string } | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const getFileIcon = (category: string) => {
    switch (category) {
      case 'document':
        return <FileText className="w-6 h-6 text-blue-500" />;
      case 'image':
        return <Image className="w-6 h-6 text-purple-500" />;
      case 'spreadsheet':
        return <FileSpreadsheet className="w-6 h-6 text-emerald-500" />;
      default:
        return <File className="w-6 h-6 text-gray-500" />;
    }
  };

  const getFileCategory = (type: string): FileItem['category'] => {
    if (type.includes('pdf') || type.includes('word') || type.includes('text')) {
      return 'document';
    }
    if (type.includes('image') || type.includes('png') || type.includes('jpg')) {
      return 'image';
    }
    if (type.includes('sheet') || type.includes('excel') || type.includes('csv')) {
      return 'spreadsheet';
    }
    return 'other';
  };

  const formatFileSize = (bytes: number): string => {
    if (bytes === 0) return '0 Bytes';
    const k = 1024;
    const sizes = ['Bytes', 'KB', 'MB', 'GB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
  };

  const handleDragOver = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(true);
  }, []);

  const handleDragLeave = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
  }, []);

  const handleDrop = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
    
    const droppedFiles = Array.from(e.dataTransfer.files);
    handleFiles(droppedFiles);
  }, []);

  const handleFileInput = useCallback((e: React.ChangeEvent<HTMLInputElement>) => {
    const selectedFiles = Array.from(e.target.files || []);
    handleFiles(selectedFiles);
  }, []);

  const handleFiles = (newFiles: File[]) => {
    newFiles.forEach((file, index) => {
      const fileId = `upload-${Date.now()}-${index}`;
      
      // Simulate upload progress
      let progress = 0;
      const interval = setInterval(() => {
        progress += 10;
        setUploadProgress((prev) => ({ ...prev, [fileId]: progress }));
        
        if (progress >= 100) {
          clearInterval(interval);
          
          // Add file to list
          const newFileItem: FileItem = {
            id: fileId,
            name: file.name,
            type: file.type,
            size: formatFileSize(file.size),
            uploadedAt: new Date().toISOString().split('T')[0],
            category: getFileCategory(file.type),
          };
          
          setFiles((prev) => [newFileItem, ...prev]);
          setUploadProgress((prev) => {
            const updated = { ...prev };
            delete updated[fileId];
            return updated;
          });
          
          showNotification('success', `File "${file.name}" uploaded successfully!`);
        }
      }, 100);
    });
  };

  const handleDelete = (fileId: string) => {
    setFiles((prev) => prev.filter((f) => f.id !== fileId));
    showNotification('success', 'File deleted successfully');
  };

  const handleDownload = (file: FileItem) => {
    // Simulate download
    showNotification('success', `Downloading "${file.name}"...`);
    
    // Create a dummy download
    const link = document.createElement('a');
    link.href = '#';
    link.download = file.name;
    link.click();
  };

  const showNotification = (type: 'success' | 'error', message: string) => {
    setNotification({ type, message });
    setTimeout(() => setNotification(null), 3000);
  };

  return (
    <div id="files" className="section-card border border-purple-200 overflow-hidden">
      {/* Header */}
      <div className="section-header bg-gradient-to-r from-purple-50 to-white">
        <div className="flex items-center gap-4">
          <div className="w-12 h-12 rounded-xl bg-purple-100 text-purple-600 flex items-center justify-center flex-shrink-0">
            <Upload className="w-6 h-6" />
          </div>
          <div>
            <h2 className="font-heading text-xl md:text-2xl font-bold text-purple-900">
              File Manager
            </h2>
            <p className="font-heading text-sm text-gray-500 mt-1">
              Upload, download, and manage your documents
            </p>
          </div>
        </div>
      </div>

      {/* Content */}
      <div className="p-6">
        {/* Upload Zone */}
        <div
          onDragOver={handleDragOver}
          onDragLeave={handleDragLeave}
          onDrop={handleDrop}
          onClick={() => fileInputRef.current?.click()}
          className={`file-upload-zone mb-6 ${isDragging ? 'dragover' : ''}`}
        >
          <input
            ref={fileInputRef}
            type="file"
            multiple
            onChange={handleFileInput}
            className="hidden"
          />
          <div className="w-16 h-16 rounded-full bg-purple-100 flex items-center justify-center mx-auto mb-4">
            <Upload className="w-8 h-8 text-purple-600" />
          </div>
          <p className="font-heading text-lg font-medium text-gray-700 mb-2">
            Drop files here or click to upload
          </p>
          <p className="font-heading text-sm text-gray-500">
            Supports PDF, Word, Excel, Images (max 10MB each)
          </p>
        </div>

        {/* Upload Progress */}
        {Object.entries(uploadProgress).length > 0 && (
          <div className="mb-6 space-y-3">
            {Object.entries(uploadProgress).map(([id, progress]) => (
              <div key={id} className="bg-gray-50 rounded-lg p-4">
                <div className="flex items-center justify-between mb-2">
                  <span className="font-heading text-sm text-gray-700">Uploading...</span>
                  <span className="font-heading text-sm text-purple-600">{progress}%</span>
                </div>
                <div className="w-full h-2 bg-gray-200 rounded-full overflow-hidden">
                  <div
                    className="h-full bg-purple-500 transition-all duration-300"
                    style={{ width: `${progress}%` }}
                  />
                </div>
              </div>
            ))}
          </div>
        )}

        {/* File List */}
        <div className="space-y-3">
          <div className="flex items-center justify-between mb-4">
            <h3 className="font-heading text-lg font-semibold text-gray-900">
              Your Files ({files.length})
            </h3>
            <button
              onClick={() => fileInputRef.current?.click()}
              className="inline-flex items-center gap-2 px-4 py-2 bg-purple-500 text-white text-sm font-medium rounded-lg hover:bg-purple-600 transition-colors"
            >
              <Upload className="w-4 h-4" />
              Add Files
            </button>
          </div>

          {files.length === 0 ? (
            <div className="text-center py-12 bg-gray-50 rounded-xl">
              <File className="w-12 h-12 text-gray-300 mx-auto mb-4" />
              <p className="font-heading text-gray-500">No files yet</p>
              <p className="font-heading text-sm text-gray-400">Upload your first file above</p>
            </div>
          ) : (
            <div className="grid gap-3">
              {files.map((file) => (
                <div
                  key={file.id}
                  className="flex items-center gap-4 p-4 bg-white border border-gray-100 rounded-xl hover:border-purple-200 hover:shadow-sm transition-all group"
                >
                  <div className="w-12 h-12 rounded-lg bg-gray-50 flex items-center justify-center flex-shrink-0">
                    {getFileIcon(file.category)}
                  </div>
                  
                  <div className="flex-1 min-w-0">
                    <p className="font-heading text-sm font-medium text-gray-900 truncate">
                      {file.name}
                    </p>
                    <div className="flex items-center gap-3 mt-1">
                      <span className="font-heading text-xs text-gray-500">{file.size}</span>
                      <span className="w-1 h-1 rounded-full bg-gray-300" />
                      <span className="font-heading text-xs text-gray-500">{file.uploadedAt}</span>
                    </div>
                  </div>

                  <div className="flex items-center gap-2 opacity-0 group-hover:opacity-100 transition-opacity">
                    <button
                      onClick={() => handleDownload(file)}
                      className="p-2 text-gray-500 hover:text-purple-600 hover:bg-purple-50 rounded-lg transition-colors"
                      title="Download"
                    >
                      <Download className="w-5 h-5" />
                    </button>
                    <button
                      onClick={() => handleDelete(file.id)}
                      className="p-2 text-gray-500 hover:text-red-600 hover:bg-red-50 rounded-lg transition-colors"
                      title="Delete"
                    >
                      <Trash2 className="w-5 h-5" />
                    </button>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>

        {/* Quick Downloads */}
        <div className="mt-8 pt-6 border-t border-gray-100">
          <h3 className="font-heading text-sm font-semibold text-gray-500 uppercase tracking-wider mb-4">
            Quick Downloads
          </h3>
          <div className="flex flex-wrap gap-3">
            <a
              href="#"
              className="inline-flex items-center gap-2 px-4 py-2 bg-blue-50 text-blue-700 text-sm font-medium rounded-lg hover:bg-blue-100 transition-colors"
            >
              <FileText className="w-4 h-4" />
              Download CV (PDF)
            </a>
            <a
              href="#"
              className="inline-flex items-center gap-2 px-4 py-2 bg-teal-50 text-teal-700 text-sm font-medium rounded-lg hover:bg-teal-100 transition-colors"
            >
              <FileText className="w-4 h-4" />
              Research Portfolio
            </a>
            <a
              href="#"
              className="inline-flex items-center gap-2 px-4 py-2 bg-amber-50 text-amber-700 text-sm font-medium rounded-lg hover:bg-amber-100 transition-colors"
            >
              <FileSpreadsheet className="w-4 h-4" />
              Project Data (Excel)
            </a>
          </div>
        </div>
      </div>

      {/* Notification */}
      {notification && (
        <div className="fixed bottom-4 right-4 z-[200] animate-fade-in">
          <div
            className={`flex items-center gap-3 px-4 py-3 rounded-lg shadow-lg ${
              notification.type === 'success'
                ? 'bg-emerald-500 text-white'
                : 'bg-red-500 text-white'
            }`}
          >
            {notification.type === 'success' ? (
              <CheckCircle className="w-5 h-5" />
            ) : (
              <AlertCircle className="w-5 h-5" />
            )}
            <span className="font-heading text-sm">{notification.message}</span>
            <button
              onClick={() => setNotification(null)}
              className="ml-2 hover:opacity-70"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        </div>
      )}
    </div>
  );
};

export default FileManager;
