import { useState } from 'react';
import { 
  Mail, 
  Linkedin, 
  MapPin, 
  Send,
  CheckCircle,
  AlertCircle
} from 'lucide-react';

const Contact = () => {
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    subject: '',
    message: '',
  });
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [submitStatus, setSubmitStatus] = useState<'success' | 'error' | null>(null);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);

    // Simulate form submission
    await new Promise((resolve) => setTimeout(resolve, 1500));

    setSubmitStatus('success');
    setIsSubmitting(false);
    setFormData({ name: '', email: '', subject: '', message: '' });

    setTimeout(() => setSubmitStatus(null), 5000);
  };

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    setFormData((prev) => ({
      ...prev,
      [e.target.name]: e.target.value,
    }));
  };

  return (
    <section id="contact" className="py-16 bg-gradient-to-br from-blue-50 via-white to-teal-50">
      <div className="w-full px-4 md:px-8 lg:px-12">
        <div className="max-w-6xl mx-auto">
          {/* Header */}
          <div className="text-center mb-12">
            <span className="inline-block px-4 py-2 bg-blue-100 text-blue-700 rounded-full text-sm font-medium mb-4">
              Get in Touch
            </span>
            <h2 className="font-heading text-3xl md:text-4xl font-bold text-gray-900 mb-4">
              Let's Work Together
            </h2>
            <p className="font-body text-lg text-gray-600 max-w-2xl mx-auto">
              I'm always interested in research collaborations, community projects, 
              and opportunities to apply communication design for social impact.
            </p>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
            {/* Contact Info */}
            <div>
              <div className="bg-white rounded-2xl shadow-card border border-gray-100 p-6 mb-6">
                <h3 className="font-heading font-semibold text-gray-900 mb-4">
                  Contact Information
                </h3>
                
                <div className="space-y-4">
                  <a
                    href="mailto:keiday.ali@email.com"
                    className="flex items-center gap-4 p-4 bg-blue-50 rounded-xl hover:bg-blue-100 transition-colors group"
                  >
                    <div className="w-12 h-12 rounded-xl bg-blue-500 text-white flex items-center justify-center">
                      <Mail className="w-6 h-6" />
                    </div>
                    <div>
                      <span className="block font-heading text-sm text-gray-500">Email</span>
                      <span className="block font-heading font-medium text-gray-900 group-hover:text-blue-700">
                        keiday.ali@email.com
                      </span>
                    </div>
                  </a>

                  <a
                    href="https://linkedin.com"
                    target="_blank"
                    rel="noopener noreferrer"
                    className="flex items-center gap-4 p-4 bg-teal-50 rounded-xl hover:bg-teal-100 transition-colors group"
                  >
                    <div className="w-12 h-12 rounded-xl bg-teal-500 text-white flex items-center justify-center">
                      <Linkedin className="w-6 h-6" />
                    </div>
                    <div>
                      <span className="block font-heading text-sm text-gray-500">LinkedIn</span>
                      <span className="block font-heading font-medium text-gray-900 group-hover:text-teal-700">
                        linkedin.com/in/keidayali
                      </span>
                    </div>
                  </a>

                  <div className="flex items-center gap-4 p-4 bg-amber-50 rounded-xl">
                    <div className="w-12 h-12 rounded-xl bg-amber-500 text-white flex items-center justify-center">
                      <MapPin className="w-6 h-6" />
                    </div>
                    <div>
                      <span className="block font-heading text-sm text-gray-500">Location</span>
                      <span className="block font-heading font-medium text-gray-900">
                        Toronto, Canada
                      </span>
                    </div>
                  </div>
                </div>
              </div>

              {/* Availability */}
              <div className="bg-white rounded-2xl shadow-card border border-gray-100 p-6">
                <h3 className="font-heading font-semibold text-gray-900 mb-4">
                  Current Availability
                </h3>
                <div className="flex items-center gap-3 mb-4">
                  <span className="w-3 h-3 rounded-full bg-green-500 animate-pulse" />
                  <span className="font-heading text-gray-700">
                    Available for new projects
                  </span>
                </div>
                <div className="flex flex-wrap gap-2">
                  <span className="px-3 py-1.5 bg-blue-50 text-blue-700 rounded-lg font-heading text-sm">
                    Research Collaborations
                  </span>
                  <span className="px-3 py-1.5 bg-teal-50 text-teal-700 rounded-lg font-heading text-sm">
                    Consulting
                  </span>
                  <span className="px-3 py-1.5 bg-amber-50 text-amber-700 rounded-lg font-heading text-sm">
                    Design Projects
                  </span>
                </div>
              </div>
            </div>

            {/* Contact Form */}
            <div className="bg-white rounded-2xl shadow-card border border-gray-100 p-6">
              <h3 className="font-heading font-semibold text-gray-900 mb-4">
                Send a Message
              </h3>

              <form onSubmit={handleSubmit} className="space-y-4">
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div>
                    <label className="block font-heading text-sm text-gray-700 mb-1">
                      Your Name
                    </label>
                    <input
                      type="text"
                      name="name"
                      value={formData.name}
                      onChange={handleChange}
                      required
                      className="w-full px-4 py-2.5 border border-gray-300 rounded-lg font-heading text-sm focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none transition-all"
                      placeholder="John Doe"
                    />
                  </div>
                  <div>
                    <label className="block font-heading text-sm text-gray-700 mb-1">
                      Email Address
                    </label>
                    <input
                      type="email"
                      name="email"
                      value={formData.email}
                      onChange={handleChange}
                      required
                      className="w-full px-4 py-2.5 border border-gray-300 rounded-lg font-heading text-sm focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none transition-all"
                      placeholder="john@example.com"
                    />
                  </div>
                </div>

                <div>
                  <label className="block font-heading text-sm text-gray-700 mb-1">
                    Subject
                  </label>
                  <select
                    name="subject"
                    value={formData.subject}
                    onChange={handleChange}
                    required
                    className="w-full px-4 py-2.5 border border-gray-300 rounded-lg font-heading text-sm focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none transition-all"
                  >
                    <option value="">Select a subject</option>
                    <option value="research">Research Collaboration</option>
                    <option value="consulting">Consulting Opportunity</option>
                    <option value="design">Design Project</option>
                    <option value="speaking">Speaking Engagement</option>
                    <option value="other">Other</option>
                  </select>
                </div>

                <div>
                  <label className="block font-heading text-sm text-gray-700 mb-1">
                    Message
                  </label>
                  <textarea
                    name="message"
                    value={formData.message}
                    onChange={handleChange}
                    required
                    rows={4}
                    className="w-full px-4 py-2.5 border border-gray-300 rounded-lg font-heading text-sm focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none transition-all resize-none"
                    placeholder="Tell me about your project..."
                  />
                </div>

                <button
                  type="submit"
                  disabled={isSubmitting}
                  className="w-full inline-flex items-center justify-center gap-2 px-6 py-3 bg-blue-600 text-white font-heading font-medium rounded-xl hover:bg-blue-700 transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
                >
                  {isSubmitting ? (
                    <>
                      <div className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                      Sending...
                    </>
                  ) : (
                    <>
                      <Send className="w-5 h-5" />
                      Send Message
                    </>
                  )}
                </button>

                {/* Status Messages */}
                {submitStatus === 'success' && (
                  <div className="flex items-center gap-2 p-4 bg-emerald-50 text-emerald-700 rounded-lg">
                    <CheckCircle className="w-5 h-5" />
                    <span className="font-heading text-sm">
                      Message sent successfully! I'll get back to you soon.
                    </span>
                  </div>
                )}

                {submitStatus === 'error' && (
                  <div className="flex items-center gap-2 p-4 bg-red-50 text-red-700 rounded-lg">
                    <AlertCircle className="w-5 h-5" />
                    <span className="font-heading text-sm">
                      Something went wrong. Please try again.
                    </span>
                  </div>
                )}
              </form>
            </div>
          </div>

          {/* Footer */}
          <footer className="mt-16 pt-8 border-t border-gray-200">
            <div className="flex flex-col md:flex-row items-center justify-between gap-4">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-full bg-gradient-to-br from-blue-500 to-teal-500 flex items-center justify-center text-white font-bold">
                  KA
                </div>
                <div>
                  <span className="font-heading font-semibold text-gray-900 block">
                    Keiday Ali
                  </span>
                  <span className="font-heading text-xs text-gray-500">
                    Researcher & Communication Designer
                  </span>
                </div>
              </div>

              <p className="font-heading text-sm text-gray-500">
                © {new Date().getFullYear()} Keiday Ali. All rights reserved.
              </p>

              <div className="flex items-center gap-4">
                <a
                  href="mailto:keiday.ali@email.com"
                  className="font-heading text-sm text-gray-500 hover:text-blue-600 transition-colors"
                >
                  Email
                </a>
                <a
                  href="https://linkedin.com"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="font-heading text-sm text-gray-500 hover:text-blue-600 transition-colors"
                >
                  LinkedIn
                </a>
                <a
                  href="#files"
                  className="font-heading text-sm text-gray-500 hover:text-blue-600 transition-colors"
                >
                  Files
                </a>
              </div>
            </div>
          </footer>
        </div>
      </div>
    </section>
  );
};

export default Contact;
