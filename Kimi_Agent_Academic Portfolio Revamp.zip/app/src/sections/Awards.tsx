import { Trophy, Award, Star, Medal, Download, ExternalLink } from 'lucide-react';
import ExpandableSection from '../components/ExpandableSection';

interface AwardItem {
  title: string;
  organization: string;
  year: string;
  description: string;
  type: 'award' | 'certification' | 'fellowship';
}

const awards: AwardItem[] = [
  {
    title: 'Graduate Research Fellowship',
    organization: 'Toronto Metropolitan University',
    year: '2023',
    description: 'Awarded for excellence in migration research and community engagement.',
    type: 'fellowship',
  },
  {
    title: 'Excellence in Communication Design',
    organization: 'Reichman University',
    year: '2022',
    description: 'Recognized for outstanding design portfolio and creative projects.',
    type: 'award',
  },
  {
    title: 'Community Leadership Award',
    organization: 'African Students Organization',
    year: '2021',
    description: 'For contributions to student community building and cultural initiatives.',
    type: 'award',
  },
];

const certifications: AwardItem[] = [
  {
    title: 'TCPS2 Certification',
    organization: 'Canadian Research Ethics Board',
    year: '2023',
    description: 'Tri-Council Policy Statement: Ethical Conduct for Research Involving Humans',
    type: 'certification',
  },
  {
    title: 'UX Research Certificate',
    organization: 'Stanford Online',
    year: '2022',
    description: 'User Experience Research Methods and Strategy',
    type: 'certification',
  },
  {
    title: 'Data Visualization Certificate',
    organization: 'Columbia University',
    year: '2022',
    description: 'Advanced data visualization and storytelling techniques',
    type: 'certification',
  },
  {
    title: 'Peace & Conflict Studies',
    organization: 'YaLa Peace Institute',
    year: '2021',
    description: 'Leadership program for peace and reconciliation',
    type: 'certification',
  },
];

const getTypeIcon = (type: string) => {
  switch (type) {
    case 'award':
      return <Trophy className="w-5 h-5" />;
    case 'fellowship':
      return <Star className="w-5 h-5" />;
    case 'certification':
      return <Award className="w-5 h-5" />;
    default:
      return <Medal className="w-5 h-5" />;
  }
};

const getTypeColor = (type: string) => {
  switch (type) {
    case 'award':
      return 'bg-amber-100 text-amber-600';
    case 'fellowship':
      return 'bg-purple-100 text-purple-600';
    case 'certification':
      return 'bg-blue-100 text-blue-600';
    default:
      return 'bg-gray-100 text-gray-600';
  }
};

const Awards = () => {
  return (
    <ExpandableSection
      id="awards"
      title="Awards & Certifications"
      subtitle="Recognition and Professional Credentials"
      icon={<Trophy className="w-6 h-6" />}
      color="amber"
      defaultExpanded={false}
    >
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        {/* Awards Column */}
        <div>
          <h3 className="font-heading font-semibold text-gray-900 mb-4 flex items-center gap-2">
            <Star className="w-5 h-5 text-amber-500" />
            Awards & Honors
          </h3>
          <div className="space-y-3">
            {awards.map((award) => (
              <div
                key={award.title}
                className="p-4 bg-gradient-to-r from-amber-50 to-white rounded-xl border border-amber-100 hover:shadow-sm transition-all"
              >
                <div className="flex items-start gap-3">
                  <div className={`w-10 h-10 rounded-lg ${getTypeColor(award.type)} flex items-center justify-center flex-shrink-0`}>
                    {getTypeIcon(award.type)}
                  </div>
                  <div className="flex-1">
                    <div className="flex items-start justify-between gap-2">
                      <h4 className="font-heading font-semibold text-gray-900">
                        {award.title}
                      </h4>
                      <span className="px-2 py-1 bg-amber-100 text-amber-700 rounded-md font-heading text-xs flex-shrink-0">
                        {award.year}
                      </span>
                    </div>
                    <p className="font-heading text-sm text-amber-700 mt-1">
                      {award.organization}
                    </p>
                    <p className="font-body text-sm text-gray-500 mt-2">
                      {award.description}
                    </p>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Certifications Column */}
        <div>
          <h3 className="font-heading font-semibold text-gray-900 mb-4 flex items-center gap-2">
            <Award className="w-5 h-5 text-blue-500" />
            Certifications
          </h3>
          <div className="space-y-3">
            {certifications.map((cert) => (
              <div
                key={cert.title}
                className="p-4 bg-white rounded-xl border border-gray-200 hover:border-blue-200 hover:shadow-sm transition-all"
              >
                <div className="flex items-start gap-3">
                  <div className={`w-10 h-10 rounded-lg ${getTypeColor(cert.type)} flex items-center justify-center flex-shrink-0`}>
                    {getTypeIcon(cert.type)}
                  </div>
                  <div className="flex-1">
                    <div className="flex items-start justify-between gap-2">
                      <h4 className="font-heading font-semibold text-gray-900">
                        {cert.title}
                      </h4>
                      <span className="px-2 py-1 bg-blue-100 text-blue-700 rounded-md font-heading text-xs flex-shrink-0">
                        {cert.year}
                      </span>
                    </div>
                    <p className="font-heading text-sm text-gray-600 mt-1">
                      {cert.organization}
                    </p>
                    <p className="font-body text-sm text-gray-500 mt-2">
                      {cert.description}
                    </p>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Download All */}
      <div className="mt-6 p-5 bg-gradient-to-r from-gray-50 to-white rounded-xl border border-gray-200">
        <div className="flex flex-col sm:flex-row items-center justify-between gap-4">
          <div>
            <h4 className="font-heading font-semibold text-gray-900">
              Download All Credentials
            </h4>
            <p className="font-body text-sm text-gray-500">
              Get a complete package of certificates and awards
            </p>
          </div>
          <div className="flex gap-2">
            <button className="inline-flex items-center gap-2 px-4 py-2 bg-amber-500 text-white font-heading text-sm font-medium rounded-lg hover:bg-amber-600 transition-colors">
              <Download className="w-4 h-4" />
              Download All
            </button>
            <button className="inline-flex items-center gap-2 px-4 py-2 bg-white border border-gray-300 text-gray-700 font-heading text-sm font-medium rounded-lg hover:bg-gray-50 transition-colors">
              <ExternalLink className="w-4 h-4" />
              View Online
            </button>
          </div>
        </div>
      </div>
    </ExpandableSection>
  );
};

export default Awards;
