import { useState } from 'react';
import { Heart, Calendar, MapPin, ChevronRight, ExternalLink } from 'lucide-react';
import ExpandableSection from '../components/ExpandableSection';

interface CommunityItem {
  role: string;
  organization: string;
  location: string;
  duration: string;
  description: string;
  impact: string[];
  website?: string;
}

const communityItems: CommunityItem[] = [
  {
    role: 'Volunteer',
    organization: 'African Refugee Development Center',
    location: 'Tel Aviv, Israel',
    duration: '2021 - 2023',
    description: 'Supported community integration programs and language learning initiatives for African refugees.',
    impact: [
      'Facilitated weekly language exchange sessions',
      'Assisted with job readiness workshops',
      'Mentored 10+ individuals on settlement processes',
    ],
    website: 'https://ardc-israel.org',
  },
  {
    role: 'Member & Organizer',
    organization: 'African Students Organization',
    location: 'Herzliya, Israel',
    duration: '2019 - 2022',
    description: 'Active member supporting African student community and cultural exchange programs.',
    impact: [
      'Organized cultural events and workshops',
      'Advocated for student support services',
      'Built network of 50+ student members',
    ],
  },
  {
    role: 'Volunteer',
    organization: 'Canadian Centre for Victims of Torture',
    location: 'Toronto, Canada',
    duration: '2022 - Present',
    description: 'Supporting survivors of torture and war trauma through community programs.',
    impact: [
      'Provide interpretation services in multiple languages',
      'Assist with community outreach programs',
      'Support mental health awareness initiatives',
    ],
    website: 'https://ccvt.org',
  },
  {
    role: 'Activist & Member',
    organization: 'Amnesty International',
    location: 'Global',
    duration: '2020 - Present',
    description: 'Human rights advocacy focusing on refugee rights and migration justice.',
    impact: [
      'Participated in awareness campaigns',
      'Advocated for policy changes',
      'Organized community education events',
    ],
    website: 'https://amnesty.org',
  },
];

const CommunityWork = () => {
  const [expandedItem, setExpandedItem] = useState<number | null>(null);

  return (
    <ExpandableSection
      id="community"
      title="Community Work"
      subtitle="Volunteering and Social Impact"
      icon={<Heart className="w-6 h-6" />}
      color="coral"
      defaultExpanded={false}
    >
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {communityItems.map((item, index) => {
          const isExpanded = expandedItem === index;

          return (
            <div
              key={item.organization}
              onClick={() => setExpandedItem(isExpanded ? null : index)}
              className={`p-5 rounded-xl border cursor-pointer transition-all duration-300 ${
                isExpanded
                  ? 'border-orange-200 shadow-card-hover bg-gradient-to-r from-orange-50 to-white'
                  : 'border-gray-200 shadow-card bg-white hover:border-orange-200'
              }`}
            >
              {/* Header */}
              <div className="flex items-start justify-between mb-3">
                <div>
                  <span className="inline-block px-2 py-1 bg-orange-100 text-orange-700 rounded-md font-heading text-xs font-medium mb-2">
                    {item.role}
                  </span>
                  <h4 className="font-heading font-semibold text-gray-900">
                    {item.organization}
                  </h4>
                </div>
                <ChevronRight
                  className={`w-5 h-5 text-gray-400 transition-transform duration-300 ${
                    isExpanded ? 'rotate-90' : ''
                  }`}
                />
              </div>

              {/* Meta */}
              <div className="flex flex-wrap items-center gap-3 text-xs text-gray-500 mb-3">
                <span className="flex items-center gap-1">
                  <MapPin className="w-3 h-3" />
                  {item.location}
                </span>
                <span className="flex items-center gap-1">
                  <Calendar className="w-3 h-3" />
                  {item.duration}
                </span>
              </div>

              {/* Description */}
              <p className="font-body text-sm text-gray-600 mb-3">
                {item.description}
              </p>

              {/* Expandable Impact */}
              <div
                className={`overflow-hidden transition-all duration-300 ${
                  isExpanded ? 'max-h-[300px] opacity-100' : 'max-h-0 opacity-0'
                }`}
              >
                <div className="pt-3 border-t border-orange-100">
                  <h5 className="font-heading font-medium text-gray-900 mb-2 text-sm">
                    Impact & Contributions
                  </h5>
                  <ul className="space-y-1 mb-3">
                    {item.impact.map((impact, idx) => (
                      <li key={idx} className="flex items-start gap-2">
                        <span className="w-1.5 h-1.5 rounded-full bg-orange-500 mt-1.5 flex-shrink-0" />
                        <span className="font-body text-sm text-gray-600">
                          {impact}
                        </span>
                      </li>
                    ))}
                  </ul>

                  {item.website && (
                    <a
                      href={item.website}
                      target="_blank"
                      rel="noopener noreferrer"
                      onClick={(e) => e.stopPropagation()}
                      className="inline-flex items-center gap-1 text-orange-600 hover:text-orange-700 font-heading text-sm"
                    >
                      Visit Website
                      <ExternalLink className="w-3 h-3" />
                    </a>
                  )}
                </div>
              </div>
            </div>
          );
        })}
      </div>

      {/* Quote */}
      <div className="mt-6 p-6 bg-gradient-to-r from-orange-50 to-amber-50 rounded-xl border border-orange-100">
        <blockquote className="font-body text-gray-700 italic text-center">
          "Community work is not just about giving back—it's about building bridges, 
          amplifying voices, and creating spaces where everyone belongs."
        </blockquote>
        <p className="font-heading text-sm text-gray-500 text-center mt-3">
          — Keiday Ali
        </p>
      </div>
    </ExpandableSection>
  );
};

export default CommunityWork;
