import { useState } from 'react';
import { FolderOpen, ExternalLink, ChevronRight } from 'lucide-react';
import ExpandableSection from '../components/ExpandableSection';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
} from '@/components/ui/dialog';

interface Project {
  id: number;
  title: string;
  role: string;
  description: string;
  fullDescription: string;
  methods: string[];
  outcomes: string[];
  image: string;
  color: string;
}

const projects: Project[] = [
  {
    id: 1,
    title: 'CERC Migration Research',
    role: 'Research Assistant',
    description: 'Qualitative analysis of migration patterns and settlement experiences.',
    fullDescription: 'Conducted comprehensive qualitative research on migration patterns and settlement experiences of African refugee communities in Canada. This project involved in-depth interviews with 30+ participants, policy document analysis, and the development of community-centered recommendations.',
    methods: ['In-depth Interviews', 'Policy Analysis', 'Thematic Coding', 'NVivo'],
    outcomes: [
      'Co-authored 2 research reports',
      'Presented findings at academic conference',
      'Developed community resource guide',
    ],
    image: '/images/project-migration.jpg',
    color: 'blue',
  },
  {
    id: 2,
    title: 'Digital Community Building',
    role: 'UX Researcher',
    description: 'Ethnographic study of online refugee communities.',
    fullDescription: 'An ethnographic study examining how digital platforms facilitate social connection and support among refugee communities. The research explored user behaviors, platform preferences, and the role of technology in maintaining transnational relationships.',
    methods: ['Online Ethnography', 'User Interviews', 'Journey Mapping', 'Usability Testing'],
    outcomes: [
      'Identified key platform features for community support',
      'Created user personas and journey maps',
      'Developed design recommendations',
    ],
    image: '/images/project-community.jpg',
    color: 'teal',
  },
  {
    id: 3,
    title: 'Policy Communication Design',
    role: 'Communication Designer',
    description: 'Visual storytelling for migration policy reports.',
    fullDescription: 'Designed visual communications and data visualizations for migration policy reports, making complex data accessible to diverse audiences. The project involved creating infographics, report layouts, and interactive visualizations.',
    methods: ['Visual Design', 'Data Visualization', 'Information Design', 'Adobe Creative Suite'],
    outcomes: [
      'Designed 5+ policy reports',
      'Created infographic series',
      'Developed visual style guide',
    ],
    image: '/images/project-policy.jpg',
    color: 'amber',
  },
];

const Projects = () => {
  const [selectedProject, setSelectedProject] = useState<Project | null>(null);

  return (
    <ExpandableSection
      id="projects"
      title="Selected Projects"
      subtitle="Research, Design, and Community Work"
      icon={<FolderOpen className="w-6 h-6" />}
      color="teal"
      defaultExpanded={false}
    >
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {projects.map((project) => (
          <div
            key={project.id}
            onClick={() => setSelectedProject(project)}
            className="group bg-white rounded-xl border border-gray-200 overflow-hidden cursor-pointer hover:border-teal-300 hover:shadow-card-hover transition-all duration-300"
          >
            {/* Image */}
            <div className="relative h-48 overflow-hidden">
              <img
                src={project.image}
                alt={project.title}
                className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent" />
              <div className="absolute bottom-4 left-4 right-4">
                <span className={`tag ${
                  project.color === 'blue' ? 'tag-blue' :
                  project.color === 'teal' ? 'bg-teal-100 text-teal-700' :
                  'tag-amber'
                } mb-2`}>
                  {project.role}
                </span>
                <h3 className="font-heading text-lg font-bold text-white">
                  {project.title}
                </h3>
              </div>
            </div>

            {/* Content */}
            <div className="p-5">
              <p className="font-body text-gray-600 text-sm mb-4 line-clamp-2">
                {project.description}
              </p>

              {/* Methods */}
              <div className="flex flex-wrap gap-2 mb-4">
                {project.methods.slice(0, 3).map((method) => (
                  <span
                    key={method}
                    className="px-2 py-1 bg-gray-100 rounded-md font-heading text-xs text-gray-600"
                  >
                    {method}
                  </span>
                ))}
                {project.methods.length > 3 && (
                  <span className="px-2 py-1 bg-gray-100 rounded-md font-heading text-xs text-gray-500">
                    +{project.methods.length - 3}
                  </span>
                )}
              </div>

              {/* View More */}
              <div className="flex items-center text-teal-600 font-heading text-sm font-medium group-hover:text-teal-700">
                View Details
                <ChevronRight className="w-4 h-4 ml-1 transition-transform group-hover:translate-x-1" />
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* Project Detail Dialog */}
      <Dialog open={!!selectedProject} onOpenChange={() => setSelectedProject(null)}>
        <DialogContent className="max-w-2xl max-h-[90vh] overflow-auto">
          {selectedProject && (
            <>
              <DialogHeader>
                <DialogTitle className="font-heading text-2xl">
                  {selectedProject.title}
                </DialogTitle>
                <DialogDescription className="font-heading text-teal-600">
                  {selectedProject.role}
                </DialogDescription>
              </DialogHeader>

              <div className="mt-4">
                {/* Image */}
                <div className="rounded-xl overflow-hidden mb-6">
                  <img
                    src={selectedProject.image}
                    alt={selectedProject.title}
                    className="w-full h-48 object-cover"
                  />
                </div>

                {/* Description */}
                <div className="mb-6">
                  <h4 className="font-heading font-semibold text-gray-900 mb-2">About</h4>
                  <p className="font-body text-gray-600">{selectedProject.fullDescription}</p>
                </div>

                {/* Methods */}
                <div className="mb-6">
                  <h4 className="font-heading font-semibold text-gray-900 mb-2">Methods</h4>
                  <div className="flex flex-wrap gap-2">
                    {selectedProject.methods.map((method) => (
                      <span
                        key={method}
                        className="px-3 py-1 bg-teal-50 text-teal-700 rounded-full font-heading text-sm"
                      >
                        {method}
                      </span>
                    ))}
                  </div>
                </div>

                {/* Outcomes */}
                <div className="mb-6">
                  <h4 className="font-heading font-semibold text-gray-900 mb-2">Key Outcomes</h4>
                  <ul className="space-y-2">
                    {selectedProject.outcomes.map((outcome, idx) => (
                      <li key={idx} className="flex items-start gap-2">
                        <span className="w-1.5 h-1.5 rounded-full bg-teal-500 mt-2 flex-shrink-0" />
                        <span className="font-body text-gray-600">{outcome}</span>
                      </li>
                    ))}
                  </ul>
                </div>

                {/* Actions */}
                <div className="flex gap-3">
                  <button className="btn-primary">
                    <ExternalLink className="w-4 h-4" />
                    View Full Report
                  </button>
                  <button className="btn-secondary">
                    Download PDF
                  </button>
                </div>
              </div>
            </>
          )}
        </DialogContent>
      </Dialog>
    </ExpandableSection>
  );
};

export default Projects;
