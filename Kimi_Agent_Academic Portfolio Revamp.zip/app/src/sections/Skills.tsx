import { useState } from 'react';
import { Wrench, ChevronRight, Star } from 'lucide-react';
import ExpandableSection from '../components/ExpandableSection';

interface SkillCategory {
  title: string;
  skills: { name: string; level: number }[];
  color: string;
}

const skillCategories: SkillCategory[] = [
  {
    title: 'Research Methods',
    color: 'blue',
    skills: [
      { name: 'Qualitative Interviews', level: 95 },
      { name: 'Online Ethnography', level: 90 },
      { name: 'Policy Analysis', level: 85 },
      { name: 'Focus Groups', level: 88 },
      { name: 'Case Study Research', level: 92 },
      { name: 'Participatory Methods', level: 80 },
    ],
  },
  {
    title: 'Technical Skills',
    color: 'teal',
    skills: [
      { name: 'Data Visualization', level: 90 },
      { name: 'NVivo / Atlas.ti', level: 85 },
      { name: 'Figma & Design Tools', level: 88 },
      { name: 'SPSS / R (Basic)', level: 70 },
      { name: 'Adobe Creative Suite', level: 82 },
      { name: 'UX Research Tools', level: 85 },
    ],
  },
  {
    title: 'Communication',
    color: 'amber',
    skills: [
      { name: 'Visual Storytelling', level: 92 },
      { name: 'Report Writing', level: 90 },
      { name: 'Academic Publishing', level: 85 },
      { name: 'Presentation Design', level: 88 },
      { name: 'Stakeholder Engagement', level: 87 },
      { name: 'Community Outreach', level: 90 },
    ],
  },
  {
    title: 'Languages',
    color: 'purple',
    skills: [
      { name: 'English', level: 100 },
      { name: 'Arabic', level: 95 },
      { name: 'Fur', level: 100 },
      { name: 'Beria/Zaghawa', level: 95 },
      { name: 'Hebrew', level: 85 },
    ],
  },
];

const Skills = () => {
  const [expandedCategory, setExpandedCategory] = useState<string | null>('Research Methods');

  const toggleCategory = (title: string) => {
    setExpandedCategory(expandedCategory === title ? null : title);
  };

  const getColorClasses = (color: string) => {
    const classes: { [key: string]: { bg: string; bar: string; text: string } } = {
      blue: { bg: 'bg-blue-50', bar: 'bg-blue-500', text: 'text-blue-700' },
      teal: { bg: 'bg-teal-50', bar: 'bg-teal-500', text: 'text-teal-700' },
      amber: { bg: 'bg-amber-50', bar: 'bg-amber-500', text: 'text-amber-700' },
      purple: { bg: 'bg-purple-50', bar: 'bg-purple-500', text: 'text-purple-700' },
    };
    return classes[color] || classes.blue;
  };

  return (
    <ExpandableSection
      id="skills"
      title="Skills & Methods"
      subtitle="Expertise and Proficiencies"
      icon={<Wrench className="w-6 h-6" />}
      color="amber"
      defaultExpanded={false}
    >
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {skillCategories.map((category) => {
          const colors = getColorClasses(category.color);
          const isExpanded = expandedCategory === category.title;

          return (
            <div
              key={category.title}
              className={`rounded-xl border border-gray-200 overflow-hidden transition-all duration-300 ${
                isExpanded ? 'shadow-card-hover' : 'shadow-card'
              }`}
            >
              {/* Category Header */}
              <button
                onClick={() => toggleCategory(category.title)}
                className={`w-full px-5 py-4 flex items-center justify-between ${colors.bg} hover:opacity-90 transition-opacity`}
              >
                <div className="flex items-center gap-3">
                  <h3 className={`font-heading font-semibold ${colors.text}`}>
                    {category.title}
                  </h3>
                  <span className="px-2 py-0.5 bg-white rounded-full font-heading text-xs text-gray-500">
                    {category.skills.length}
                  </span>
                </div>
                <ChevronRight
                  className={`w-5 h-5 text-gray-400 transition-transform duration-300 ${
                    isExpanded ? 'rotate-90' : ''
                  }`}
                />
              </button>

              {/* Skills List */}
              <div
                className={`overflow-hidden transition-all duration-300 ${
                  isExpanded ? 'max-h-[500px] opacity-100' : 'max-h-0 opacity-0'
                }`}
              >
                <div className="p-5 space-y-4">
                  {category.skills.map((skill) => (
                    <div key={skill.name}>
                      <div className="flex items-center justify-between mb-1">
                        <span className="font-heading text-sm text-gray-700">
                          {skill.name}
                        </span>
                        <div className="flex items-center gap-1">
                          {[...Array(5)].map((_, i) => (
                            <Star
                              key={i}
                              className={`w-3 h-3 ${
                                i < Math.ceil(skill.level / 20)
                                  ? 'text-amber-400 fill-amber-400'
                                  : 'text-gray-200'
                              }`}
                            />
                          ))}
                        </div>
                      </div>
                      <div className="w-full h-2 bg-gray-100 rounded-full overflow-hidden">
                        <div
                          className={`h-full ${colors.bar} transition-all duration-500`}
                          style={{ width: `${skill.level}%` }}
                        />
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          );
        })}
      </div>

      {/* Summary */}
      <div className="mt-6 p-5 bg-gradient-to-r from-gray-50 to-white rounded-xl border border-gray-100">
        <h4 className="font-heading font-semibold text-gray-900 mb-3">Core Competencies</h4>
        <div className="flex flex-wrap gap-2">
          {[
            'Qualitative Research',
            'Data Analysis',
            'Visual Communication',
            'Policy Research',
            'Community Engagement',
            'UX Research',
            'Multilingual',
            'Cross-cultural',
          ].map((competency) => (
            <span
              key={competency}
              className="px-3 py-1.5 bg-white border border-gray-200 rounded-lg font-heading text-sm text-gray-700 hover:border-amber-300 hover:bg-amber-50 transition-colors cursor-default"
            >
              {competency}
            </span>
          ))}
        </div>
      </div>
    </ExpandableSection>
  );
};

export default Skills;
