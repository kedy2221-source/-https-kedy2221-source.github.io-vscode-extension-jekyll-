import { useState } from 'react';
import { Briefcase, Calendar, MapPin, ChevronRight, CheckCircle2 } from 'lucide-react';
import ExpandableSection from '../components/ExpandableSection';

interface WorkItem {
  position: string;
  organization: string;
  location: string;
  duration: string;
  type: string;
  description: string;
  achievements: string[];
}

const workItems: WorkItem[] = [
  {
    position: 'Research Assistant',
    organization: 'CERC Migration',
    location: 'Toronto, Canada',
    duration: '2022 - 2024',
    type: 'Full-time',
    description: 'Conducted qualitative research on migration and settlement experiences of refugee communities in Canada.',
    achievements: [
      'Conducted 30+ in-depth interviews with refugee communities',
      'Analyzed policy documents and produced comprehensive literature reviews',
      'Co-authored 2 research reports on digital migration experiences',
      'Presented findings at academic conferences',
    ],
  },
  {
    position: 'Research Assistant',
    organization: 'Hebrew University',
    location: 'Jerusalem, Israel',
    duration: '2021 - 2022',
    type: 'Part-time',
    description: 'Supported research on communication and digital media studies with focus on community engagement.',
    achievements: [
      'Assisted with data collection and qualitative analysis',
      'Developed visual materials for research presentations',
      'Coordinated participant recruitment and interview scheduling',
      'Managed research database and documentation',
    ],
  },
  {
    position: 'Communication Designer',
    organization: 'Freelance & Projects',
    location: 'Remote',
    duration: '2020 - Present',
    type: 'Contract',
    description: 'Design visual communications for research institutions and community organizations.',
    achievements: [
      'Created infographics and data visualizations for 10+ policy reports',
      'Designed user interfaces for community-focused applications',
      'Developed brand identities for 5+ non-profit organizations',
      'Produced visual content for social media campaigns',
    ],
  },
];

const WorkExperience = () => {
  const [expandedItem, setExpandedItem] = useState<number | null>(0);

  return (
    <ExpandableSection
      id="work"
      title="Work Experience"
      subtitle="Professional Roles and Research Positions"
      icon={<Briefcase className="w-6 h-6" />}
      color="green"
      defaultExpanded={false}
    >
      <div className="space-y-4">
        {workItems.map((item, index) => {
          const isExpanded = expandedItem === index;

          return (
            <div
              key={item.position + item.organization}
              className={`rounded-xl border transition-all duration-300 ${
                isExpanded
                  ? 'border-emerald-200 shadow-card-hover bg-white'
                  : 'border-gray-200 shadow-card bg-white hover:border-emerald-200'
              }`}
            >
              {/* Header - Always Visible */}
              <button
                onClick={() => setExpandedItem(isExpanded ? null : index)}
                className="w-full px-5 py-4 flex items-center justify-between"
              >
                <div className="flex items-start gap-4 text-left">
                  <div className="w-12 h-12 rounded-xl bg-emerald-100 flex items-center justify-center flex-shrink-0">
                    <Briefcase className="w-6 h-6 text-emerald-600" />
                  </div>
                  <div>
                    <h4 className="font-heading font-semibold text-gray-900">
                      {item.position}
                    </h4>
                    <p className="font-heading text-sm text-emerald-700 mt-0.5">
                      {item.organization}
                    </p>
                    <div className="flex flex-wrap items-center gap-3 mt-2 text-xs text-gray-500">
                      <span className="flex items-center gap-1">
                        <MapPin className="w-3 h-3" />
                        {item.location}
                      </span>
                      <span className="flex items-center gap-1">
                        <Calendar className="w-3 h-3" />
                        {item.duration}
                      </span>
                      <span className="px-2 py-0.5 bg-gray-100 rounded-full">
                        {item.type}
                      </span>
                    </div>
                  </div>
                </div>
                <ChevronRight
                  className={`w-5 h-5 text-gray-400 transition-transform duration-300 ${
                    isExpanded ? 'rotate-90' : ''
                  }`}
                />
              </button>

              {/* Expandable Content */}
              <div
                className={`overflow-hidden transition-all duration-300 ${
                  isExpanded ? 'max-h-[500px] opacity-100' : 'max-h-0 opacity-0'
                }`}
              >
                <div className="px-5 pb-5 pt-2 border-t border-gray-100">
                  <p className="font-body text-gray-600 mb-4">
                    {item.description}
                  </p>

                  <h5 className="font-heading font-medium text-gray-900 mb-2 text-sm">
                    Key Achievements
                  </h5>
                  <ul className="space-y-2">
                    {item.achievements.map((achievement, idx) => (
                      <li key={idx} className="flex items-start gap-2">
                        <CheckCircle2 className="w-4 h-4 text-emerald-500 mt-0.5 flex-shrink-0" />
                        <span className="font-body text-sm text-gray-600">
                          {achievement}
                        </span>
                      </li>
                    ))}
                  </ul>
                </div>
              </div>
            </div>
          );
        })}
      </div>

      {/* Download Resume */}
      <div className="mt-6 flex justify-center">
        <button className="inline-flex items-center gap-2 px-6 py-3 bg-emerald-500 text-white font-heading font-medium rounded-xl hover:bg-emerald-600 transition-colors shadow-lg">
          <Briefcase className="w-5 h-5" />
          Download Full Resume
        </button>
      </div>
    </ExpandableSection>
  );
};

export default WorkExperience;
