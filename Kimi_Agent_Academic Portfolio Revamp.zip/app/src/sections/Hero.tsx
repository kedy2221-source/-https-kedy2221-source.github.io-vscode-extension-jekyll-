import { useEffect, useRef, useState } from 'react';
import { Mail, Linkedin, FileText, ChevronDown, MapPin, Globe } from 'lucide-react';

const Hero = () => {
  const [isVisible, setIsVisible] = useState(false);
  const sectionRef = useRef<HTMLElement>(null);

  useEffect(() => {
    setIsVisible(true);
  }, []);

  const scrollToContent = () => {
    document.querySelector('#about')?.scrollIntoView({ behavior: 'smooth' });
  };

  return (
    <section
      ref={sectionRef}
      className="relative min-h-screen bg-gradient-to-br from-white via-blue-50/30 to-teal-50/20 pt-20"
    >
      <div className="w-full px-4 md:px-8 lg:px-12 py-12 md:py-20">
        <div className="max-w-7xl mx-auto">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center min-h-[calc(100vh-160px)]">
            {/* Left Content */}
            <div className={`transition-all duration-700 ${isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-8'}`}>
              {/* Badge */}
              <div className="inline-flex items-center gap-2 px-4 py-2 bg-blue-100 text-blue-700 rounded-full text-sm font-medium mb-6">
                <Globe className="w-4 h-4" />
                Available for collaborations
              </div>

              {/* Title */}
              <h1 className="font-heading text-4xl md:text-5xl lg:text-6xl font-bold text-gray-900 mb-4 leading-tight">
                Researcher &<br />
                <span className="text-transparent bg-clip-text bg-gradient-to-r from-blue-600 to-teal-500">
                  Communication Designer
                </span>
              </h1>

              {/* Subtitle */}
              <p className="font-body text-lg md:text-xl text-gray-600 mb-6 max-w-lg">
                Specializing in migration studies, digital media, and community-centered research 
                with expertise in qualitative methods and visual storytelling.
              </p>

              {/* Location */}
              <div className="flex items-center gap-2 text-gray-500 mb-8">
                <MapPin className="w-4 h-4" />
                <span className="font-heading text-sm">Toronto, Canada</span>
              </div>

              {/* Quick Stats */}
              <div className="flex flex-wrap gap-4 mb-8">
                <div className="px-4 py-3 bg-white rounded-xl shadow-card border border-gray-100">
                  <span className="block font-heading text-2xl font-bold text-blue-600">5+</span>
                  <span className="block font-heading text-xs text-gray-500">Languages</span>
                </div>
                <div className="px-4 py-3 bg-white rounded-xl shadow-card border border-gray-100">
                  <span className="block font-heading text-2xl font-bold text-teal-600">4+</span>
                  <span className="block font-heading text-xs text-gray-500">Years Research</span>
                </div>
                <div className="px-4 py-3 bg-white rounded-xl shadow-card border border-gray-100">
                  <span className="block font-heading text-2xl font-bold text-amber-500">10+</span>
                  <span className="block font-heading text-xs text-gray-500">Projects</span>
                </div>
              </div>

              {/* CTAs */}
              <div className="flex flex-wrap gap-3">
                <a
                  href="mailto:keiday.ali@email.com"
                  className="inline-flex items-center gap-2 px-6 py-3 bg-blue-600 text-white font-heading font-medium rounded-xl hover:bg-blue-700 transition-colors shadow-lg hover:shadow-xl"
                >
                  <Mail className="w-5 h-5" />
                  Get in Touch
                </a>
                <a
                  href="https://linkedin.com"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="inline-flex items-center gap-2 px-6 py-3 bg-white text-gray-700 font-heading font-medium rounded-xl border border-gray-300 hover:bg-gray-50 transition-colors"
                >
                  <Linkedin className="w-5 h-5" />
                  LinkedIn
                </a>
                <a
                  href="#"
                  className="inline-flex items-center gap-2 px-6 py-3 bg-amber-500 text-white font-heading font-medium rounded-xl hover:bg-amber-600 transition-colors shadow-lg hover:shadow-xl"
                >
                  <FileText className="w-5 h-5" />
                  Download CV
                </a>
              </div>
            </div>

            {/* Right Content - Image */}
            <div className={`relative transition-all duration-700 delay-200 ${isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-8'}`}>
              <div className="relative">
                {/* Background decoration */}
                <div className="absolute -top-8 -right-8 w-72 h-72 bg-gradient-to-br from-blue-200/50 to-teal-200/50 rounded-full blur-3xl" />
                <div className="absolute -bottom-8 -left-8 w-64 h-64 bg-gradient-to-br from-amber-200/50 to-orange-200/50 rounded-full blur-3xl" />
                
                {/* Main Image */}
                <div className="relative rounded-2xl overflow-hidden shadow-2xl border-4 border-white">
                  <img
                    src="/images/hero-portrait.jpg"
                    alt="Keiday Ali"
                    className="w-full aspect-[4/5] object-cover"
                  />
                </div>

                {/* Floating badges */}
                <div className="absolute -bottom-4 -left-4 px-4 py-3 bg-white rounded-xl shadow-card border border-gray-100">
                  <div className="flex items-center gap-2">
                    <div className="w-8 h-8 rounded-full bg-teal-100 flex items-center justify-center">
                      <span className="text-teal-600 text-lg">🎓</span>
                    </div>
                    <div>
                      <span className="block font-heading text-xs text-gray-500">Education</span>
                      <span className="block font-heading text-sm font-semibold text-gray-900">MA Immigration Studies</span>
                    </div>
                  </div>
                </div>

                <div className="absolute -top-4 -right-4 px-4 py-3 bg-white rounded-xl shadow-card border border-gray-100">
                  <div className="flex items-center gap-2">
                    <div className="w-8 h-8 rounded-full bg-amber-100 flex items-center justify-center">
                      <span className="text-amber-600 text-lg">🏆</span>
                    </div>
                    <div>
                      <span className="block font-heading text-xs text-gray-500">Certified</span>
                      <span className="block font-heading text-sm font-semibold text-gray-900">TCPS2 Research Ethics</span>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Scroll Indicator */}
      <button
        onClick={scrollToContent}
        className="absolute bottom-8 left-1/2 -translate-x-1/2 flex flex-col items-center gap-2 text-gray-400 hover:text-blue-600 transition-colors"
      >
        <span className="font-heading text-xs uppercase tracking-widest">Scroll to explore</span>
        <ChevronDown className="w-5 h-5 animate-bounce" />
      </button>
    </section>
  );
};

export default Hero;
