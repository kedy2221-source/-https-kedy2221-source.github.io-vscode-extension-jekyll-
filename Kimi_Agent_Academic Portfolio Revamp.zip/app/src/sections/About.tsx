import { User, MapPin, GraduationCap, Globe } from 'lucide-react';
import ExpandableSection from '../components/ExpandableSection';

const About = () => {
  return (
    <ExpandableSection
      id="about"
      title="About Me"
      subtitle="Researcher, Designer, and Community Advocate"
      icon={<User className="w-6 h-6" />}
      color="blue"
      defaultExpanded={true}
    >
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        {/* Left Column - Bio */}
        <div>
          <div className="prose prose-gray max-w-none">
            <p className="font-body text-gray-700 text-lg leading-relaxed mb-4">
              I am a researcher and communication designer specializing in <strong>migration studies</strong>, 
              <strong> digital media</strong>, and <strong>community-centered research</strong>. My work bridges 
              the gap between academic research and practical community impact.
            </p>
            <p className="font-body text-gray-600 leading-relaxed mb-4">
              With a Master's in Immigration & Settlement Studies from Toronto Metropolitan University 
              and a Bachelor's in Communications from Reichman University (IDC Herzliya), I bring a unique 
              interdisciplinary perspective to understanding the intersection of technology, migration, 
              and community building.
            </p>
            <p className="font-body text-gray-600 leading-relaxed">
              My research focuses on qualitative methods including interviews, online ethnography, 
              and policy analysis. I'm passionate about amplifying voices from the Global South and 
              creating meaningful digital experiences that bridge communities.
            </p>
          </div>

          {/* Key Highlights */}
          <div className="mt-6 flex flex-wrap gap-2">
            <span className="tag tag-blue">Migration Studies</span>
            <span className="tag tag-green">Qualitative Research</span>
            <span className="tag tag-amber">Digital Media</span>
            <span className="tag tag-purple">Community Building</span>
            <span className="tag tag-blue">Policy Analysis</span>
          </div>
        </div>

        {/* Right Column - Info Cards */}
        <div className="space-y-4">
          {/* Education Card */}
          <div className="bg-gradient-to-r from-blue-50 to-white p-5 rounded-xl border border-blue-100">
            <div className="flex items-start gap-4">
              <div className="w-10 h-10 rounded-lg bg-blue-100 flex items-center justify-center flex-shrink-0">
                <GraduationCap className="w-5 h-5 text-blue-600" />
              </div>
              <div>
                <h4 className="font-heading font-semibold text-gray-900">Education</h4>
                <div className="mt-2 space-y-2">
                  <div>
                    <p className="font-heading text-sm font-medium text-gray-800">MA Immigration & Settlement Studies</p>
                    <p className="font-heading text-xs text-gray-500">Toronto Metropolitan University, 2022-2024</p>
                  </div>
                  <div>
                    <p className="font-heading text-sm font-medium text-gray-800">BA Communications</p>
                    <p className="font-heading text-xs text-gray-500">Reichman University (IDC Herzliya), 2018-2022</p>
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* Location Card */}
          <div className="bg-gradient-to-r from-teal-50 to-white p-5 rounded-xl border border-teal-100">
            <div className="flex items-start gap-4">
              <div className="w-10 h-10 rounded-lg bg-teal-100 flex items-center justify-center flex-shrink-0">
                <MapPin className="w-5 h-5 text-teal-600" />
              </div>
              <div>
                <h4 className="font-heading font-semibold text-gray-900">Location</h4>
                <p className="font-body text-gray-600 mt-1">
                  Based in Toronto, Canada. Available for remote collaborations worldwide.
                </p>
              </div>
            </div>
          </div>

          {/* Languages Card */}
          <div className="bg-gradient-to-r from-amber-50 to-white p-5 rounded-xl border border-amber-100">
            <div className="flex items-start gap-4">
              <div className="w-10 h-10 rounded-lg bg-amber-100 flex items-center justify-center flex-shrink-0">
                <Globe className="w-5 h-5 text-amber-600" />
              </div>
              <div>
                <h4 className="font-heading font-semibold text-gray-900">Languages</h4>
                <div className="flex flex-wrap gap-2 mt-2">
                  <span className="px-2 py-1 bg-white rounded-md font-heading text-xs text-gray-700 border border-amber-200">English (Native)</span>
                  <span className="px-2 py-1 bg-white rounded-md font-heading text-xs text-gray-700 border border-amber-200">Arabic (Fluent)</span>
                  <span className="px-2 py-1 bg-white rounded-md font-heading text-xs text-gray-700 border border-amber-200">Fur (Native)</span>
                  <span className="px-2 py-1 bg-white rounded-md font-heading text-xs text-gray-700 border border-amber-200">Beria/Zaghawa (Fluent)</span>
                  <span className="px-2 py-1 bg-white rounded-md font-heading text-xs text-gray-700 border border-amber-200">Hebrew (Advanced)</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </ExpandableSection>
  );
};

export default About;
