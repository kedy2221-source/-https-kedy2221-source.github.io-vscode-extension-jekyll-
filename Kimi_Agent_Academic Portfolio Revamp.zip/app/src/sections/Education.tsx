import { GraduationCap, Calendar, MapPin, Award, BookOpen, CheckCircle } from 'lucide-react';
import ExpandableSection from '../components/ExpandableSection';

interface EducationItem {
  degree: string;
  institution: string;
  location: string;
  year: string;
  details: string[];
  thesis?: string;
}

const educationItems: EducationItem[] = [
  {
    degree: 'MA in Immigration & Settlement Studies',
    institution: 'Toronto Metropolitan University',
    location: 'Toronto, Canada',
    year: '2022 - 2024',
    details: [
      'Graduate Research Fellowship recipient',
      'Focus on digital communities and migration experiences',
      'Coursework in qualitative methods and policy analysis',
    ],
    thesis: 'Digital Communities and Migration Experiences: An Ethnographic Study',
  },
  {
    degree: 'BA in Communications',
    institution: 'Reichman University (IDC Herzliya)',
    location: 'Herzliya, Israel',
    year: '2018 - 2022',
    details: [
      'Specialization in Interactive Communication Design & Analysis',
      'Excellence in Communication Design award',
      'Dean\'s List recognition',
    ],
    thesis: 'Digital Platforms and Community Building Among Refugee Populations',
  },
];

const certifications = [
  {
    name: 'TCPS2: Ethical Conduct for Research',
    provider: 'Canadian Research Ethics Board',
    year: '2023',
    description: 'Tri-Council Policy Statement certification for research involving humans',
  },
  {
    name: 'UX Research Certificate',
    provider: 'Stanford Online',
    year: '2022',
    description: 'User Experience Research Methods and Strategy',
  },
  {
    name: 'Data Visualization Certificate',
    provider: 'Columbia University',
    year: '2022',
    description: 'Advanced data visualization and storytelling techniques',
  },
  {
    name: 'Peace & Conflict Studies',
    provider: 'YaLa Peace Institute',
    year: '2021',
    description: 'Leadership program for peace and reconciliation',
  },
];

const Education = () => {
  return (
    <ExpandableSection
      id="education"
      title="Education & Training"
      subtitle="Academic Background and Professional Development"
      icon={<GraduationCap className="w-6 h-6" />}
      color="purple"
      defaultExpanded={false}
    >
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        {/* Education */}
        <div>
          <h3 className="font-heading font-semibold text-gray-900 mb-4 flex items-center gap-2">
            <BookOpen className="w-5 h-5 text-purple-600" />
            Academic Degrees
          </h3>
          <div className="space-y-4">
            {educationItems.map((item) => (
              <div
                key={item.degree}
                className="p-5 bg-gradient-to-r from-purple-50 to-white rounded-xl border border-purple-100"
              >
                <div className="flex items-start justify-between mb-3">
                  <div>
                    <h4 className="font-heading font-semibold text-gray-900">
                      {item.degree}
                    </h4>
                    <p className="font-heading text-sm text-purple-700 mt-1">
                      {item.institution}
                    </p>
                  </div>
                </div>

                <div className="flex flex-wrap items-center gap-4 mb-3 text-sm text-gray-500">
                  <span className="flex items-center gap-1">
                    <MapPin className="w-4 h-4" />
                    {item.location}
                  </span>
                  <span className="flex items-center gap-1">
                    <Calendar className="w-4 h-4" />
                    {item.year}
                  </span>
                </div>

                {item.thesis && (
                  <div className="mb-3 p-3 bg-white rounded-lg border border-purple-100">
                    <span className="font-heading text-xs text-purple-600 uppercase tracking-wider">
                      Thesis/MRP
                    </span>
                    <p className="font-body text-sm text-gray-700 mt-1">
                      {item.thesis}
                    </p>
                  </div>
                )}

                <ul className="space-y-1">
                  {item.details.map((detail, idx) => (
                    <li key={idx} className="flex items-start gap-2">
                      <CheckCircle className="w-4 h-4 text-purple-500 mt-0.5 flex-shrink-0" />
                      <span className="font-body text-sm text-gray-600">{detail}</span>
                    </li>
                  ))}
                </ul>
              </div>
            ))}
          </div>
        </div>

        {/* Certifications */}
        <div>
          <h3 className="font-heading font-semibold text-gray-900 mb-4 flex items-center gap-2">
            <Award className="w-5 h-5 text-amber-600" />
            Certifications
          </h3>
          <div className="space-y-3">
            {certifications.map((cert) => (
              <div
                key={cert.name}
                className="p-4 bg-white rounded-xl border border-gray-200 hover:border-amber-200 hover:shadow-sm transition-all"
              >
                <div className="flex items-start justify-between mb-2">
                  <h4 className="font-heading font-medium text-gray-900">
                    {cert.name}
                  </h4>
                  <span className="px-2 py-1 bg-amber-100 text-amber-700 rounded-md font-heading text-xs">
                    {cert.year}
                  </span>
                </div>
                <p className="font-heading text-sm text-gray-500 mb-1">
                  {cert.provider}
                </p>
                <p className="font-body text-xs text-gray-400">
                  {cert.description}
                </p>
              </div>
            ))}
          </div>

          {/* Download Transcripts */}
          <div className="mt-6 p-4 bg-gradient-to-r from-gray-50 to-white rounded-xl border border-gray-200">
            <h4 className="font-heading font-medium text-gray-900 mb-3">
              Academic Documents
            </h4>
            <div className="flex flex-wrap gap-2">
              <button className="inline-flex items-center gap-2 px-4 py-2 bg-white border border-gray-300 rounded-lg font-heading text-sm text-gray-700 hover:bg-gray-50 transition-colors">
                <Award className="w-4 h-4" />
                Download Transcripts
              </button>
              <button className="inline-flex items-center gap-2 px-4 py-2 bg-white border border-gray-300 rounded-lg font-heading text-sm text-gray-700 hover:bg-gray-50 transition-colors">
                <GraduationCap className="w-4 h-4" />
                Degree Certificates
              </button>
            </div>
          </div>
        </div>
      </div>
    </ExpandableSection>
  );
};

export default Education;
