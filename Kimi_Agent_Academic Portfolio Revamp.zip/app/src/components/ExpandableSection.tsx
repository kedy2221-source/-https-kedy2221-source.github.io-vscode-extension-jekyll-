import { useState, useRef, useEffect } from 'react';
import { ChevronDown, ChevronUp } from 'lucide-react';

interface ExpandableSectionProps {
  id: string;
  title: string;
  subtitle?: string;
  icon?: React.ReactNode;
  color?: 'blue' | 'teal' | 'amber' | 'purple' | 'green' | 'coral';
  defaultExpanded?: boolean;
  children: React.ReactNode;
}

const colorClasses = {
  blue: {
    header: 'from-blue-50 to-white hover:from-blue-100 hover:to-blue-50',
    icon: 'bg-blue-100 text-blue-600',
    title: 'text-blue-900',
    border: 'border-blue-200',
  },
  teal: {
    header: 'from-teal-50 to-white hover:from-teal-100 hover:to-teal-50',
    icon: 'bg-teal-100 text-teal-600',
    title: 'text-teal-900',
    border: 'border-teal-200',
  },
  amber: {
    header: 'from-amber-50 to-white hover:from-amber-100 hover:to-amber-50',
    icon: 'bg-amber-100 text-amber-600',
    title: 'text-amber-900',
    border: 'border-amber-200',
  },
  purple: {
    header: 'from-purple-50 to-white hover:from-purple-100 hover:to-purple-50',
    icon: 'bg-purple-100 text-purple-600',
    title: 'text-purple-900',
    border: 'border-purple-200',
  },
  green: {
    header: 'from-emerald-50 to-white hover:from-emerald-100 hover:to-emerald-50',
    icon: 'bg-emerald-100 text-emerald-600',
    title: 'text-emerald-900',
    border: 'border-emerald-200',
  },
  coral: {
    header: 'from-orange-50 to-white hover:from-orange-100 hover:to-orange-50',
    icon: 'bg-orange-100 text-orange-600',
    title: 'text-orange-900',
    border: 'border-orange-200',
  },
};

const ExpandableSection = ({
  id,
  title,
  subtitle,
  icon,
  color = 'blue',
  defaultExpanded = false,
  children,
}: ExpandableSectionProps) => {
  const [isExpanded, setIsExpanded] = useState(defaultExpanded);
  const contentRef = useRef<HTMLDivElement>(null);
  const [contentHeight, setContentHeight] = useState(0);

  useEffect(() => {
    if (contentRef.current) {
      setContentHeight(contentRef.current.scrollHeight);
    }
  }, [children]);

  const toggleExpand = () => {
    setIsExpanded(!isExpanded);
  };

  const colors = colorClasses[color];

  return (
    <div
      id={id}
      className={`section-card border ${colors.border} overflow-hidden`}
    >
      {/* Header - Clickable */}
      <button
        onClick={toggleExpand}
        className={`section-header w-full bg-gradient-to-r ${colors.header}`}
      >
        <div className="flex items-center gap-4">
          {icon && (
            <div className={`w-12 h-12 rounded-xl ${colors.icon} flex items-center justify-center flex-shrink-0`}>
              {icon}
            </div>
          )}
          <div className="text-left">
            <h2 className={`font-heading text-xl md:text-2xl font-bold ${colors.title}`}>
              {title}
            </h2>
            {subtitle && (
              <p className="font-heading text-sm text-gray-500 mt-1">{subtitle}</p>
            )}
          </div>
        </div>
        <div className={`w-10 h-10 rounded-full bg-white shadow-sm flex items-center justify-center transition-transform duration-300 ${isExpanded ? 'rotate-180' : ''}`}>
          {isExpanded ? (
            <ChevronUp className="w-5 h-5 text-gray-600" />
          ) : (
            <ChevronDown className="w-5 h-5 text-gray-600" />
          )}
        </div>
      </button>

      {/* Expandable Content */}
      <div
        className="overflow-hidden transition-all duration-500 ease-in-out"
        style={{
          maxHeight: isExpanded ? contentHeight : 0,
          opacity: isExpanded ? 1 : 0,
        }}
      >
        <div ref={contentRef} className="p-6">
          {children}
        </div>
      </div>
    </div>
  );
};

export default ExpandableSection;
